package ma.enset.productsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
